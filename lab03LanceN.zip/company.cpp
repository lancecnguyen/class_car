#include "company.h"

//company::company() 	{

//}

company::company(string n, string a, long p) 
	: name(n), address(a), phone(p)
{
}