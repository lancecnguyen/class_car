#pragma once
#include <string>
using namespace std;

class company {
private:
	string name;
	string address;
	long phone;
public:
	//company();
	company(string, string, long);


};